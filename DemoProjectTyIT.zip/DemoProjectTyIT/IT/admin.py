# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

    # the module name is app_name.models
from IT.models import Department,Library,Student



class DepartmentAdmin(admin.ModelAdmin):
	list_display = ['dept_name', 'dept_desc']
admin.site.register(Department, DepartmentAdmin)

class LibraryAdmin(admin.ModelAdmin):
	list_display = ['book_name','book_date']
	search_fields = ['book_name','book_date']
	list_filter = ['book_name','book_date']
admin.site.register(Library, LibraryAdmin)

class StudentAdmin(admin.ModelAdmin):
	list_display = ['name','D_name']
	# search_fields = ['name','D_name']

admin.site.register(Student, StudentAdmin)
 
