# -*- coding: utf-8 -*-

 
from django.db import models

class Department(models.Model):
        # define department name and description columns, the id column will be added automatically.
	dept_name = models.CharField(max_length=50)
	dept_desc = models.CharField(max_length=50)

	
	 
	def __unicode__(self):
	    return self.dept_name

	

class Library(models.Model):
        # define department name and description columns, the id column will be added automatically.
	book_name = models.CharField(max_length=50)
	book_date = models.DateField()

	def __unicode__(self):
	    return self.book_name



class Student(models.Model):
        # define department name and description columns, the id column will be added automatically.
	# name = models.CharField(max_length=1000,primary_key=True)
	name = models.CharField(max_length=100,primary_key=True)
	D_name = models.ForeignKey(Department,on_delete=models.CASCADE)

	def __unicode__(self):
	    return self.name

	    # artist = models.ForeignKey(Musician, on_delete=models.CASCADE)


        # this is a inner class which is used to define unique index columns. You can specify multiple columns in a list or tuple.
    # class Meta:
    #     unique_together = ['dept_name']


# Create your models here.
