# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from django.http import HttpResponse
from django.shortcuts import render
from IT.models import Department,Library,Student



def index(request):
    return HttpResponse('Hello, welcome to 00000000 the index page.')

def individual_post(request):
    return HttpResponse('Hi, this is where an individual post will be.')

def StudentRecord(request):
   Student1 = Student.objects.all()
   return render(request, "IT/post_list.html", {"Student1" : Student1})
	

def Lib(request):
   #today = datetime.datetime.now().date()
   L1 = Library.objects.all()
   D1 = Department.objects.all()
    
   return render(request, "IT/post_lib_dept.html", { "Library1" : L1 , "Department1":D1 } )
	



# Create your views here.
